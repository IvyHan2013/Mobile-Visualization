from . import HomeScreen
from kivy.lang import Builder

Builder.load_file('screens/theming.kv')

class ThemingScreen(HomeScreen):
    pass

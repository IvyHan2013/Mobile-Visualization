from . import HomeScreen
from kivy.lang import Builder

Builder.load_file('screens/radio.kv')

class RadioScreen(HomeScreen):
    pass

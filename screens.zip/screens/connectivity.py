from . import HomeScreen
from kivy.lang import Builder

Builder.load_file('screens/connectivity.kv')

class ConnectivityScreen(HomeScreen):
    pass

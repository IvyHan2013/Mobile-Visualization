from . import HomeScreen
from kivy.lang import Builder

Builder.load_file('screens/mobility.kv')

class MobilityScreen(HomeScreen):
    pass

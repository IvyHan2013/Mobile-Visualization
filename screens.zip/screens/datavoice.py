from . import HomeScreen
from kivy.lang import Builder

Builder.load_file('screens/datavoice.kv')

class DatavoiceScreen(HomeScreen):
    pass

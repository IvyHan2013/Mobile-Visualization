from . import HomeScreen
from kivy.lang import Builder

Builder.load_file('screens/dataplane.kv')

class DataplaneScreen(HomeScreen):
    pass
